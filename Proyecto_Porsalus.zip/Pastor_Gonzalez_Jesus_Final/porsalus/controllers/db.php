<?php
/*
    Clase para la conexión con la db 
*/
    $host = "localhost";
    $usuario = "root";
    $clave = "root";
    $bd = "porsalus";

    // establecer conexion
    $enlace = mysqli_connect($host,$usuario,$clave,$bd);
    
    // verificar conexion
    if(!$enlace){
        echo"CONEXION CON LA BASE DE DATOS FALLIDA";
    }else{
        echo"CONEXIÓN CON LA BASE DE DATOS ESTABLECIDA";
    }
