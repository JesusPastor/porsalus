<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/porsalus/style/login.css">
    <title>Registro PorSalus</title>
</head>

<body>
    <form class="box" method="post">
        <h1>Alta en Porsalus</h1>
        <input type="text" name="usuario" placeholder="Usuario">
        <input type="text" name="dni" placeholder="DNI">
        <input type="text" name="mail" placeholder="E-mail">
        <input type="submit" name="registrarse" placeholder="Registrarse">
    </form>
    <?php
    include("db.php");
    // si se aprieta registrar inicia la validación
    if (isset($_POST['registrarse'])) {
        //   con srtlen() detectamos que no estén vacios siendo >= a 1
        if (
            strlen($_POST['usuario']) >= 1 &&
            strlen($_POST['dni']) >= 1 &&
            strlen($_POST['mail']) >= 1
        ) {
            $usuario = $_POST['usuario'];
            $dni = $_POST['dni'];
            $mail = $_POST['mail'];
            $consulta = "INSERT INTO usuarios (usuario, dni, mail) VALUES ('$usuario','$dni','$mail')";
            $resultado =  mysqli_query($enlace, $consulta);
            if ($resultado) {
    ?>
                <h3>¡Te has inscrito correctamente!</h3>
    <?php
                // esto deriva al index "desbloqueado" si se ha registrado correctamente
                header("Location: /porsalus/controllers/index_iniciado.php");
                exit();
            }
        } else {
            echo '<script language="javascript">alert("POR FAVOR RELLENE TODOS LOS CAMPOS");</script>';
        }
    }
    ?>
</body>

</html>