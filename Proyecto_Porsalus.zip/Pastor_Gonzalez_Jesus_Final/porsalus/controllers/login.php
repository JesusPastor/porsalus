<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/porsalus/style/login.css">
    <title>Iniciar Sesión</title>
</head>

<body>
    <form class="box" method="post">
        <h1>Inicia Sesión</h1>
        <input type="text" name="usuario" placeholder="usuario">
        <input type="text" name="dni" placeholder="dni">
        <input type="submit" name="submit" placeholder="Iniciar Sesión">
    </form>
    <?php
    include("db.php");
    // si se aprieta registrar inicia la validación
    if (isset($_POST['submit'])) {
        //   con srtlen() detectamos que no estén vacios siendo >= a 1
        if (
            strlen($_POST['usuario']) >= 1 &&
            strlen($_POST['dni']) >= 1
        ) {
            $usuario = $_POST['usuario'];
            $dni = $_POST['dni'];
            $mail = $_POST['mail'];
            $consulta = "SELECT * FROM usuarios where usuario = '$usuario' and dni = '$dni' ";
            $resultado =  mysqli_query($enlace, $consulta);
            // variable que almacena nuestro resultado
            $filas = mysqli_num_rows($resultado);
            if ($filas) {
                // esto deriva al index "desbloqueado" si se ha iniciado sesión correctamente
                header("Location: /porsalus/controllers/index_iniciado.php");
                exit();
            } else {

                echo '<script language="javascript">alert("Credenciales incorrectas");</script>';
            }
        }
    }
    ?>
</body>

</html>