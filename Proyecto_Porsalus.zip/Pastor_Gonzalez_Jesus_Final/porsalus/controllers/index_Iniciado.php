<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="/porsalus/style/style_Patologia.css" />
  <title>PorSalus</title>
</head>

<body>

  <main>
    <header>

      <div class="volver">
        <button>
          <a href="/porsalus/index.php">
            << Volver al menú principal </a>
        </button>
      </div>

      <h1>Bienvenido a PorSalus</h1>
      <!-- logo porsalus -->
      <img class="logo" src="/porsalus/view/porsalus_Logo.png" alt="logo" style="size: 100px" />
    </header>

    <h2 style="text-align: center;">Selecciona una patología</h2>

    <!-- barra de navegación -->
    <nav>
      <a href="/porsalus/patologias/gluten.php">Celiaquía</a>
      <a href="/porsalus/patologias/endo.php">Endometriósis</a>
      <a href="/porsalus/patologias/pancreas.php">Pancreatitis Crónica Autoinmune</a>
      <div class="animation-navbar"></div>
    </nav>

    <section class="description">
      <p>
        Este proyecto tiene la finalidad de dar a conocer la sintomatología de
        las enfermedades y causas de las mismas a los clientes de forma clara
        y concisa<br />
        <br />
        Dicho proyecto también puede proporcionar ayuda para encontrar
        <b>especialistas y/o administraciones</b> que traten dichas
        enfermedades anteriormente descritas en el menú desplegable de
        <b>PATOLOGÍA</b>.<br />
        <br />Como medida auxiliar ponemos a su alcance varios
        <b>productos recomendados</b> en función de la patología descrita.<br />
    </section>

  </main>
</body>

</html>