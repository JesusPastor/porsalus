<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="/porsalus/style/style.css">
  <title>PorSalus</title>
</head>

<body>

  <main>
    <header>
      <!-- menu hamburguesa aside -->
      <div class="icono-menu">
        <img src="/porsalus/view/menu.png" id="icono-menu" />
      </div>
      <!-- aside izq -->
      </div>
      <div class="cont-menu active" id="menu">
        <ul>
          <li><a href="/porsalus/controllers/login.php">Iniciar sesion</a></li>
          <li><a href="/porsalus/controllers/registro.php">Registrarse</a></li>
        </ul>
      </div>
      <h1>Bienvenido a PorSalus</h1>
      <!-- logo porsalus -->
      <img class="logo" src="/porsalus/view/porsalus_Logo.png" alt="logo" style="size: 100px" />
    </header>

    <!-- carrusel de imagenes -->
    <div class="carrusel">
      <div class="carrusel-items">
        <div class="carrusel-item">
          <img src="/porsalus/view/health.jpg" alt="imagen 1" />
        </div>
        <div class="carrusel-item">
          <img src="/porsalus/view/gluten.jpg" alt="imagen 2" />
        </div>
        <div class="carrusel-item">
          <img src="/porsalus/view/family-healthy.jpg" alt="imagen 3" />
        </div>
        <div class="carrusel-item">
          <img src="/porsalus/view/endo.png" alt="imagen 4" />
        </div>
        <div class="carrusel-item">
          <img src="/porsalus/view/pancreas.jpg" alt="imagen 5" />
        </div>
        <div class="carrusel-item">
          <img src="/porsalus/view/heal.jpg" alt="imagen 6" />
        </div>
      </div>
    </div>

    <section class="description">
      <h1>REGISTRATE O INICIA SESIÓN PARA ACCEDER A LAS PATOLOGÍAS DISPONIBLES</h1>
    </section>


    <footer>
      <p>PorSalus (Proyecto web creado por Jesús Pastor)</p>
    </footer>

    <script type="text/javascript" src="/porsalus/js/main.js"></script>
  </main>
</body>

</html>