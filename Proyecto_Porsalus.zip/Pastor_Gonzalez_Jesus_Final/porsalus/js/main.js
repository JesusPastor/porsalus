const iconoMenu = document.querySelector("#icono-menu"),
  menu = document.querySelector("#menu");

iconoMenu.addEventListener("click", (e) => {
  // Alternamos estilos para el menu y body
  menu.classList.toggle("active");
  document.body.classList.toggle("opacity");
});

/* 
carrusel
seleccionamos la clase carrusel perteneciente al DOM
*/
const carrusel = document.querySelector(".carrusel-items");
// creamos intervalo en play y stop para opcion agrandar img
let intervalo = null;
// creamos paso
let step = 1;
// creamos limite del scroll (resta del scroll da maxScrollLeft)
let maxScrollLeft = carrusel.scrollWidth - carrusel.clientWidth;
// clase start y stop para carrusel
const start = () => {
  intervalo = setInterval(function () {
    //controlamos direccion y velocidad
    carrusel.scrollLeft = carrusel.scrollLeft + step;
    // para que repita y vuelva a posicion -1 (negativo) y vuelva a positivo
    if (carrusel.scrollLeft === maxScrollLeft) {
      step = -1;
    } else if (carrusel.scrollLeft === 0) {
      step = 1;
    }
  }, 10);
};
// para pararlo limpiamos variable intervalo
const stop = () => {
  clearInterval(intervalo);
};

// cuando mouse entre = stop
carrusel.addEventListener("mouseover", () => {
  stop();
});
// cuando mouse salga = play
carrusel.addEventListener("mouseout", () => {
  start();
});

start();
