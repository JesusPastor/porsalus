<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/porsalus/style/patologia.css">
    <title>Celiaquía</title>
</head>

<body>
    <main>
        <header>
            <div class="volver">
                <button>
                    <a href="/porsalus/controllers/index_Iniciado.php">
                        << Volver a seleccionar patologías </a>
                </button>
            </div>
        </header>
        <div class="logo">
            <br>
            <img src="/porsalus/view/porsalus_Logo.png" alt="logo" style="size: 100px;">
        </div>
        <section class="patologia">
            <h2>¿Qué es la Enfermedad Celíaca?</h2>
        </section>
        <section class="description">
            <p>La enfermedad celíaca es una afección autoinmune que daña al revestimiento del intestino delgado.
                <br><br>Este daño proviene de una reacción a la ingestión de gluten. <br><br>Esta es una sustancia que se encuentra en el trigo, la cebada, el centeno y posiblemente la avena.
            </p>
        </section>
        <br>
        <div style="margin-top: 10px; margin-left:25%; margin-bottom:5%;">
            <iframe width="750" height="350" src="https://www.youtube.com/embed/8I_5A157zJ8" title="YouTube video player" frameborder="1" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
        <nav>
            <a href="https://www.topdoctors.es/sevilla-ciudad/aparato-digestivo/">Pide cita a especialista digestivo</a>
            <a href="https://www.quironsalud.es/infanta-luisa/es/cita-medica">Pide cita en centro Quirón</a>
            <div class="animation-navbar"></div>
        </nav>
        <div class="recomendacion">
            <h2>Recomendaciones</h2>
            <div class="productos-recomendados">
                <img src="/porsalus/view/img_Php/gluten/tabla1sg.png">
                <img src="/porsalus/view/img_Php/gluten/tabla2sg.png">
            </div>
            <h2 style="margin-bottom: 5%;">Lugares para comer</h2>
            <div class="comer">
                <div class="sitios">
                    <a href="https://mybrandao.com/"><img src="/porsalus/view/img_Php/gluten/logo.png"></a>
                </div>
                <div class="sitios">
                    <a href="https://lamonellapizzeria.es/pizzeria-sin-gluten-en-sevilla/"><img src="/porsalus/view/img_Php/gluten/monella.png"></a>
                </div>
                <div class="sitios">
                    <a href="https://habanita.es/"><img src="/porsalus/view/img_Php/gluten/habanita.png"></a>
                </div>
            </div>
        </div>
    </main>
</body>

</html>